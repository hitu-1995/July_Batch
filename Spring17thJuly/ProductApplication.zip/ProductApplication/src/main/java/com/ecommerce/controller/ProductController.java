package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.model.Product;
import com.ecommerce.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping("/")
	public List<Product> getProducts(){
		return productService.getAllproducts();
	}
	
	@RequestMapping("/{productName}")
	public List<Product> getProductsByName(@PathVariable String productName){
		return productService.getAllProductsByName(productName);
		
	}
}

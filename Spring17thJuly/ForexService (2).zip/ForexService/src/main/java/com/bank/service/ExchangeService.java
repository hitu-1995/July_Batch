package com.bank.service;

import com.bank.model.Exchange;

public interface ExchangeService {
	
	public Exchange getCoversion(String from, String to);

}

insert into my_user (id, myusername, mypassword) values (1, 'CJC', '123');
insert into my_user (id, myusername, mypassword) values (2, 'CJC1', '3333');